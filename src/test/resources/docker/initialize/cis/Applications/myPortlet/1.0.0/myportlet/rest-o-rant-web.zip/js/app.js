var restORantApp = angular.module('restorantApp', [
  'ngResource',
  'restorantControllers',
  'restorantDirectives',
  'restorantServices'
]);
